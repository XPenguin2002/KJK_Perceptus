// Database setup:
const sqlite = require('sqlite3').verbose();
let db = my_database('./gallery.db');

var express = require("express");
var cors = require("cors");
var app = express();

app.use(express.json());
app.use(cors());
// ###############################################################################
// Routes

// Show all items
app.get('/gallery', function(req, res) {
	db.all(`SELECT * FROM gallery`, [], function(err, rows) {
		if (err) {
		console.error(err.message);
		return res.status(500).send("Server error");
		}
		return res.status(200).json(rows);
	});
});

// Create item
app.post('/gallery', function(req, res) {
	const requiredAttributes = ['author', 'alt', 'tags', 'image', 'description'];
	const item = req.body;
	var missingAttributes = [];
	for (let attribute of requiredAttributes) {
	  if (!item[attribute]) {
		missingAttributes.push(attribute);
	  }
	}
	if (missingAttributes.length > 0) {
	  return res.status(400).send(`Bad Request: Missing required attributes: ${missingAttributes.join(', ')}`);
	}
	db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`,
	[item.author, item.alt, item.tags, item.image, item.description], 
	function(err) {
		if (err) {
			console.error(err.message);
			return res.status(500).send("Server error");
		}
		return res.status(201).json(req.body);
		
	});
});
// Retrieve item with given id
app.get('/gallery/:id', function(req, res) {
	const id = req.params.id;
	idErrors(id, res);

	db.get(`SELECT author, alt, tags, image, description FROM gallery WHERE id = ?`, id, 
	function(err, row) {
		if (err) {
			console.error(err.message);
			return res.status(500).send("Server error");
		}
		if (!row) {
			return res.status(404).send("Not Found: ID not found in the database");
		}
		return res.status(200).json(row);
	});
});
  
// Update item with given id
app.patch('/gallery/:id', function (req, res) {
	const id = req.params.id;
	const item = req.body;
	idErrors(id, res);
	
	db.run(`UPDATE gallery SET author=?, alt=?, tags=?, image=?, description=? WHERE id=?`,
	[item.author, item.alt, item.tags, item.image, item.description, id], function (err) {
		if (err) {
		console.error(err.message);
		return res.status(500).send("Server error");
	}
		const affectedRows = this.changes;
		if (affectedRows === 0) {
		return res.status(404).send("Not Found: ID not found in the database");
	}
		return res.status(200).send(`Item with ID ${id} changed`);
	});	
});

// Delete item with given id
app.delete('/gallery/:id', function(req, res) {
	const id = req.params.id;
	idErrors(id, res); 

	db.run(`DELETE FROM gallery WHERE id = + ${id}`, function(err) {
		if (err) {
			console.error(err.message);
			return res.status(500).send("Server error");
		}
		const affectedRows = this.changes;
		if (affectedRows === 0) {
			return res.status(404).send("Not Found: ID not found in the database");
		}
		res.send(`Item with ID ${id} deleted`).status(200);
	});
});

// Reset whole base
app.get("/reset", function (req, res) {
	db.run("DELETE FROM gallery", function (err) {
		if (err) {
			console.error(err.message);;
			return res.status(500).send("Server error");
		}
		createDatabase();
	});
	res.send("Base reset");		
	return res.status(200);
});

//code for handling the errors about ids
function idErrors(id, res){
	if (!id) {
		return res.status(400).send("Bad Request: ID cannot be empty");
	}
	if (isNaN(id)) {
		return res.status(400).send("Bad Request: ID must be a number");
	}
}
// ###############################################################################
// This should start the server, after the routes have been defined, at port 3000:

app.listen(3000);
console.log("Your Web server should be up and running, waiting for requests to come in. Try http://localhost:3000/gallery");

function createDatabase(){
	db.serialize(() => {
		db.run(`
			CREATE TABLE IF NOT EXISTS gallery
			(
				id INTEGER PRIMARY KEY,
				author CHAR(100) NOT NULL,
				alt CHAR(100) NOT NULL,
				tags CHAR(256) NOT NULL,
				image char(2048) NOT NULL,
				description CHAR(1024) NOT NULL
			)
		`);
		db.all(`select count(*) as count from gallery`, function(err, result) {
			if (result[0].count == 0) {
				db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [
					"Tim Berners-Lee",
					"Image of Berners-Lee",
					"html,http,url,cern,mit",
					"https://upload.wikimedia.org/wikipedia/commons/9/9d/Sir_Tim_Berners-Lee.jpg",
					"The internet and the Web aren't the same thing."
					]);
				db.run(`INSERT INTO gallery (author, alt, tags, image, description) VALUES (?, ?, ?, ?, ?)`, [
					"Grace Hopper",
					"Image of Grace Hopper at the UNIVAC I console",
					"programming,linking,navy",
					"https://upload.wikimedia.org/wikipedia/commons/3/37/Grace_Hopper_and_UNIVAC.jpg",
				"Grace was very curious as a child; this was a lifelong trait. At the age of seven, she decided to determine how an alarm clock worked and dismantled seven alarm clocks before her mother realized what she was doing (she was then limited to one clock)."
					]);
				console.log('Inserted dummy photo entry into empty database');
			} else {
				console.log("Database already contains", result[0].count, "item(s) at startup.");
			}
		});
	});
}
function my_database(filename) {
	var db = new sqlite.Database(filename, (err) => {
  		if (err) {
			console.error(err.message);
  		}
		createDatabase();
  		console.log('Connected to the phones database.');
	});
	return db;
}
