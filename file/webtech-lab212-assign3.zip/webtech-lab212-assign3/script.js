const tableBodyElement = document.querySelector("tbody");
const listElement = document.getElementsByClassName('unorderedList')[0];
const authorsSet = new Set();

document.addEventListener("DOMContentLoaded", async function (){   
    await fetch('http://localhost:3000/gallery')
    .then(response => response.json())
    .then(data => {
        data.forEach(post =>{
            var row = document.createElement("tr");
            row.className = "allRows";
            row.id = `${post.id}`;
            row.value = `${post.author}`;
            var nameCell = document.createElement("td");
            nameCell.innerHTML = `<h3>${post.author}</h3>`;
            row.appendChild(nameCell);
            var imageCell = document.createElement("td");
            imageCell.innerHTML = `<img src="${post.image}">`;
            row.appendChild(imageCell);
            var altCell = document.createElement("td");
            altCell.innerHTML = `${post.alt}`;
            row.appendChild(altCell);          
            var tagsCell = document.createElement("td");
            tagsCell.innerHTML = `${post.tags}`;
            row.appendChild(tagsCell);          
            var descriptionCell = document.createElement("td");
            descriptionCell.innerHTML = `${post.description}`;
            row.appendChild(descriptionCell);
            tableBodyElement.appendChild(row);

            authorsSet.add(`${post.author}`);       
            });
            
        authorsSet.forEach(author => {
            var authorNameList = document.createElement("li");
            var btn = document.createElement("a");
            btn.innerHTML = author;
            btn.value = author;
            btn.addEventListener("click", function () {
                console.log("Button " + btn.value + " is clicked");
                var rows = document.getElementsByClassName("allRows");
                    for (element of rows) {
                        element.style.display = "table-row";
                        if (element.value != btn.value){
                            element.style.display = "none";
                        }
                    }
                }),
            listElement.appendChild(authorNameList);
            authorNameList.appendChild(btn); 
        }); 

        // reference of filter function:
        //https://www.w3schools.com/howto/howto_js_portfolio_filter.asp
        var showAllButton = document.getElementById("showAll");
        showAllButton.addEventListener("click", function () {
            console.log("Button " + "Show All" + " is clicked");
            var rows = document.getElementsByClassName("allRows");
                for (element of rows) {
                    element.style.display = "table-row";}
        })
    })
    .catch(error => {
        console.error('Error: ',error);
    });
});

var form = document.getElementById("formElem");
form.addEventListener("submit", async function(event) {
    event.preventDefault();
    var formData = {};
    formData.author = document.getElementById("author").value;
    formData.image = document.getElementById("image").value;
    formData.alt = document.getElementById("alt").value;
    formData.tags = document.getElementById("tags").value;
    formData.description = document.getElementById("description").value;
    formData.manuallyAdded = true;

    if (authorsSet.has(formData.author)) {
        console.log("continue to update");
        //Update: replace the existing authors' information with the user input
        let rows = document.getElementsByClassName("allRows");
        for (element of rows) {
            if (element.value === formData.author){
                id = element.id;
                var rowToUpdate = element;
                break;
            }
        }
        var UpdateData =            
        {"id":id,
        "author":formData.author,
        "alt":formData.alt,
        "tags":formData.tags,
        "image":formData.image,
        "description":formData.description};

        await fetch("http://localhost:3000/gallery" + id, {
            method: 'PUT',
            body: JSON.stringify(UpdateData),
            headers: {'Content-Type': 'application/json'}
        })
        .then(function(response) {
            console.log("updated");
            rowToUpdate.cells[0].innerHTML = `<h3>${formData.author}</h3>`;
            rowToUpdate.cells[1].innerHTML = `<img src="${formData.image}">`;
            rowToUpdate.cells[2].innerHTML = formData.alt;
            rowToUpdate.cells[3].innerHTML = formData.tags;
            rowToUpdate.cells[4].innerHTML = formData.description;
        })
        .then(data => {
            console.log("Data updated :)");
        })
        .catch(function(error) {
            console.error('Fail to update: ', error);
        });
    }
    else {
        //Submit: author does not exist. Use 'Submit' to add new author.
        await fetch('http://localhost:3000/gallery', {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: {'Content-Type': 'application/json'}
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
            var row = document.createElement("tr");
            row.className = "manuallyAdded";
            row.value = `${formData.author}`;
            var nameCell = document.createElement("td");
            nameCell.innerHTML = `<h3>${formData.author}</h3>`;
            row.appendChild(nameCell);
            var imageCell = document.createElement("td");
            imageCell.innerHTML = `<img src="${formData.image}">`;
            row.appendChild(imageCell);
            var altCell = document.createElement("td");
            altCell.innerHTML = `${formData.alt}`;
            row.appendChild(altCell);          
            var tagsCell = document.createElement("td");
            tagsCell.innerHTML = `${formData.tags}`;
            row.appendChild(tagsCell);          
            var descriptionCell = document.createElement("td");
            descriptionCell.innerHTML = `${formData.description}`;
            row.appendChild(descriptionCell);

            tableBodyElement.appendChild(row);
            console.log("Data submitted");

            authorsSet.add(`${formData.author}`);    
            var authorNameList = document.createElement("li"); 
            authorNameList.className = "manuallyAddedAuthor";
            var btn = document.createElement("a");
            btn.innerHTML = formData.author;
            btn.value = formData.author;
            listElement.appendChild(authorNameList); 
            authorNameList.appendChild(btn); 
        })
        .catch(error => {
            console.error('Error: ',error);
        });
    }
});

//Resetting doesn't work for updated content, it only changes after refreshing. We've tried many ways to implement it but we ran out of ideas.
document.getElementById("reset").addEventListener("click", resetData);
    function resetData() {
    fetch("http://localhost:3000/gallery/reset", {
            method: 'GET'})
            
        .then(response => {
            console.log("Data is reset.");
        })
        .then(data =>{
            var manuallyAddedRows = document.getElementsByClassName("manuallyAdded");
            while (manuallyAddedRows.length > 0) {
                tableBodyElement.removeChild(manuallyAddedRows[0]);  
            }
            var manuallyAddedAuthors = document.getElementsByClassName("manuallyAddedAuthor");
            while (manuallyAddedAuthors.length > 0) {
                listElement.removeChild(manuallyAddedAuthors[0]);
            }
        })
        .catch(error => {
            console.log("Something went wrong!", error);
        })
    }
/*Micromodal.js*/
MicroModal.init({
    onShow: modal => console.info(`${modal.id} is shown`),
    onClose: modal => console.info(`${modal.id} is hidden`),
    openClass: 'is-open',
    disableScroll: false,
    disableFocus: false,
    awaitOpenAnimation: false,
    awaitCloseAnimation: false,
    debugMode: false
});

document.querySelector('[data-micromodal-trigger]').addEventListener('click', function(){
    console.log('Button clicked');
    MicroModal.show('modal');
});
